"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import {
  taskSchema,
  commentSchema,
  subtaskSchema,
  progressSchema,
  MAX_UPLOAD_BYTES,
  ALLOWED_MIME,
} from "@/lib/validation";
import { isTaskStatus, isTaskLinkType } from "@/lib/enums";
import { clampProgress, progressFromSubtasks, runningHours } from "@/lib/tasks";
import { notifyUser } from "@/lib/push";

function revalidateTaskViews(taskId?: string) {
  revalidatePath("/");
  revalidatePath("/board");
  revalidatePath("/admin/tasks");
  if (taskId) revalidatePath(`/tasks/${taskId}`);
}

/** Recompute a task's progress from its subtasks (no-op when none exist). */
async function recomputeTaskProgress(taskId: string): Promise<void> {
  const subs = await prisma.subtask.findMany({ where: { taskId } });
  if (subs.length === 0) return;
  const done = subs.filter((s) => s.done).length;
  await prisma.task.update({
    where: { id: taskId },
    data: { progress: progressFromSubtasks(done, subs.length) },
  });
}

async function assertCanEdit(taskId: string, user: { id: string; role: string }) {
  const task = await prisma.task.findUnique({ where: { id: taskId } });
  if (!task) throw new Error("NOT_FOUND");
  const allowed =
    user.role === "Admin" ||
    task.createdByUserId === user.id ||
    task.assignedToUserId === user.id;
  if (!allowed) throw new Error("FORBIDDEN");
  return task;
}

export type TaskFormState = { error?: string; ok?: boolean };

function parseForm(formData: FormData) {
  return taskSchema.safeParse({
    title: formData.get("title"),
    description: formData.get("description") ?? "",
    status: formData.get("status") ?? "Todo",
    priority: formData.get("priority") ?? "Medium",
    assignedToUserId: formData.get("assignedToUserId") ?? "",
    projectId: formData.get("projectId") ?? "",
    teamId: formData.get("teamId") ?? "",
    dueDate: formData.get("dueDate") ?? "",
    estimatedHours: formData.get("estimatedHours") ?? "",
    spentHours: formData.get("spentHours") ?? "",
  });
}

export async function createTaskAction(
  _prev: TaskFormState,
  formData: FormData
): Promise<TaskFormState> {
  const user = await requireUser();
  const parsed = parseForm(formData);
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "INVALID" };
  }
  const d = parsed.data;
  // Non-admins may only create tasks assigned to themselves.
  const assignee = user.role === "Admin" ? d.assignedToUserId : user.id;

  const task = await prisma.task.create({
    data: {
      title: d.title,
      description: d.description || null,
      status: d.status,
      priority: d.priority,
      assignedToUserId: assignee,
      projectId: d.projectId,
      teamId: d.teamId,
      dueDate: d.dueDate,
      estimatedHours: d.estimatedHours,
      spentHours: d.spentHours,
      progress: d.status === "Done" ? 100 : 0,
      completedAt: d.status === "Done" ? new Date() : null,
      createdByUserId: user.id,
    },
  });

  if (assignee && assignee !== user.id) {
    await notifyUser(assignee, {
      title: "Neue Task zugewiesen",
      body: d.title,
      url: `/tasks/${task.id}`,
    });
  }

  revalidatePath("/");
  revalidatePath("/board");
  redirect(`/tasks/${task.id}`);
}

export async function updateTaskAction(
  taskId: string,
  _prev: TaskFormState,
  formData: FormData
): Promise<TaskFormState> {
  const user = await requireUser();
  const existing = await assertCanEdit(taskId, user);
  const parsed = parseForm(formData);
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "INVALID" };
  }
  const d = parsed.data;

  const becameDone = d.status === "Done" && existing.status !== "Done";
  const leftDone = d.status !== "Done" && existing.status === "Done";
  const subtaskCount = await prisma.subtask.count({ where: { taskId } });
  // Non-admins cannot reassign tasks — keep the existing assignee.
  const assignee =
    user.role === "Admin"
      ? d.assignedToUserId
      : (existing.assignedToUserId ?? user.id);

  await prisma.task.update({
    where: { id: taskId },
    data: {
      title: d.title,
      description: d.description || null,
      status: d.status,
      priority: d.priority,
      assignedToUserId: assignee,
      projectId: d.projectId,
      teamId: d.teamId,
      dueDate: d.dueDate,
      estimatedHours: d.estimatedHours,
      spentHours: d.spentHours,
      ...(becameDone ? { completedAt: new Date() } : {}),
      ...(leftDone ? { completedAt: null } : {}),
      // Mark fully complete when manually set to Done (only when no subtasks drive it)
      ...(becameDone && subtaskCount === 0 ? { progress: 100 } : {}),
    },
  });

  if (
    assignee &&
    assignee !== existing.assignedToUserId &&
    assignee !== user.id
  ) {
    await notifyUser(assignee, {
      title: "Task zugewiesen",
      body: d.title,
      url: `/tasks/${taskId}`,
    });
  }

  revalidatePath("/");
  revalidatePath("/board");
  revalidatePath(`/tasks/${taskId}`);
  redirect(`/tasks/${taskId}`);
}

/** Used by the Kanban board drag&drop. */
export async function updateTaskStatusAction(
  taskId: string,
  status: string
): Promise<{ ok: boolean }> {
  const user = await requireUser();
  const existing = await assertCanEdit(taskId, user);
  if (!isTaskStatus(status)) return { ok: false };

  const becameDone = status === "Done" && existing.status !== "Done";
  const leftDone = status !== "Done" && existing.status === "Done";
  const subtaskCount = await prisma.subtask.count({ where: { taskId } });

  await prisma.task.update({
    where: { id: taskId },
    data: {
      status,
      ...(becameDone ? { completedAt: new Date() } : {}),
      ...(leftDone ? { completedAt: null } : {}),
      ...(becameDone && subtaskCount === 0 ? { progress: 100 } : {}),
    },
  });

  revalidateTaskViews(taskId);
  return { ok: true };
}

export async function deleteTaskAction(taskId: string): Promise<void> {
  const user = await requireUser();
  await assertCanEdit(taskId, user);
  await prisma.task.delete({ where: { id: taskId } });
  revalidatePath("/");
  revalidatePath("/board");
  redirect("/");
}

export async function addCommentAction(
  taskId: string,
  _prev: { error?: string },
  formData: FormData
): Promise<{ error?: string }> {
  const user = await requireUser();
  await assertCanEdit(taskId, user);
  const parsed = commentSchema.safeParse({ content: formData.get("content") });
  if (!parsed.success) return { error: "INVALID" };

  await prisma.taskComment.create({
    data: { taskId, userId: user.id, content: parsed.data.content },
  });

  revalidatePath(`/tasks/${taskId}`);
  return {};
}

export async function uploadAttachmentAction(
  taskId: string,
  formData: FormData
): Promise<{ error?: string }> {
  const user = await requireUser();
  await assertCanEdit(taskId, user);

  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return { error: "NO_FILE" };
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return { error: "TOO_LARGE" };
  }
  if (!ALLOWED_MIME.includes(file.type)) {
    return { error: "BAD_TYPE" };
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  const ext = path.extname(file.name) || "";
  const safeName = `${randomBytes(12).toString("hex")}${ext}`;
  const uploadDir = path.join(process.cwd(), "public", "uploads");
  await mkdir(uploadDir, { recursive: true });
  await writeFile(path.join(uploadDir, safeName), bytes);

  await prisma.taskAttachment.create({
    data: {
      taskId,
      fileName: file.name,
      filePath: `/uploads/${safeName}`,
      mimeType: file.type,
      sizeBytes: file.size,
    },
  });

  revalidatePath(`/tasks/${taskId}`);
  return {};
}

/* ------------------------------------------------------------------ */
/* Progress                                                            */
/* ------------------------------------------------------------------ */

/** Manual progress update (ignored when the task has subtasks). */
export async function updateTaskProgressAction(
  taskId: string,
  progress: number
): Promise<{ ok: boolean }> {
  const user = await requireUser();
  await assertCanEdit(taskId, user);

  const parsed = progressSchema.safeParse({ progress });
  if (!parsed.success) return { ok: false };

  const subtaskCount = await prisma.subtask.count({ where: { taskId } });
  if (subtaskCount > 0) return { ok: false }; // subtasks drive progress

  const value = clampProgress(parsed.data.progress);
  await prisma.task.update({
    where: { id: taskId },
    data: { progress: value },
  });

  revalidateTaskViews(taskId);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Subtasks                                                           */
/* ------------------------------------------------------------------ */

export async function addSubtaskAction(
  taskId: string,
  _prev: { error?: string },
  formData: FormData
): Promise<{ error?: string }> {
  const user = await requireUser();
  await assertCanEdit(taskId, user);

  const parsed = subtaskSchema.safeParse({ title: formData.get("title") });
  if (!parsed.success) return { error: "INVALID" };

  const max = await prisma.subtask.aggregate({
    where: { taskId },
    _max: { order: true },
  });

  await prisma.subtask.create({
    data: {
      taskId,
      title: parsed.data.title,
      order: (max._max.order ?? -1) + 1,
    },
  });

  await recomputeTaskProgress(taskId);
  revalidateTaskViews(taskId);
  return {};
}

export async function toggleSubtaskAction(
  subtaskId: string
): Promise<{ ok: boolean }> {
  const user = await requireUser();
  const sub = await prisma.subtask.findUnique({ where: { id: subtaskId } });
  if (!sub) return { ok: false };
  await assertCanEdit(sub.taskId, user);

  await prisma.subtask.update({
    where: { id: subtaskId },
    data: { done: !sub.done },
  });

  await recomputeTaskProgress(sub.taskId);
  revalidateTaskViews(sub.taskId);
  return { ok: true };
}

export async function deleteSubtaskAction(
  subtaskId: string
): Promise<{ ok: boolean }> {
  const user = await requireUser();
  const sub = await prisma.subtask.findUnique({ where: { id: subtaskId } });
  if (!sub) return { ok: false };
  await assertCanEdit(sub.taskId, user);

  await prisma.subtask.delete({ where: { id: subtaskId } });
  await recomputeTaskProgress(sub.taskId);
  revalidateTaskViews(sub.taskId);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Time tracking — start / stop timer                                 */
/* ------------------------------------------------------------------ */

export async function startTimerAction(
  taskId: string
): Promise<{ ok: boolean }> {
  const user = await requireUser();
  const task = await assertCanEdit(taskId, user);
  if (task.timerStartedAt) return { ok: true }; // already running

  await prisma.task.update({
    where: { id: taskId },
    data: { timerStartedAt: new Date() },
  });
  revalidateTaskViews(taskId);
  return { ok: true };
}

export async function stopTimerAction(
  taskId: string
): Promise<{ ok: boolean }> {
  const user = await requireUser();
  const task = await assertCanEdit(taskId, user);
  if (!task.timerStartedAt) return { ok: true };

  const elapsed = runningHours(task.timerStartedAt);
  await prisma.task.update({
    where: { id: taskId },
    data: {
      spentHours: Math.round((task.spentHours + elapsed) * 100) / 100,
      timerStartedAt: null,
    },
  });
  revalidateTaskViews(taskId);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Task links / dependencies                                          */
/* ------------------------------------------------------------------ */

export async function addTaskLinkAction(
  taskId: string,
  linkedTaskId: string,
  type: string
): Promise<{ ok: boolean; error?: string }> {
  const user = await requireUser();
  await assertCanEdit(taskId, user);
  if (!isTaskLinkType(type)) return { ok: false, error: "TYPE" };
  if (!linkedTaskId || linkedTaskId === taskId) {
    return { ok: false, error: "SELF" };
  }
  const target = await prisma.task.findUnique({ where: { id: linkedTaskId } });
  if (!target) return { ok: false, error: "NOT_FOUND" };

  await prisma.taskLink
    .create({ data: { taskId, linkedTaskId, type } })
    .catch(() => {}); // ignore duplicate (unique constraint)

  revalidateTaskViews(taskId);
  return { ok: true };
}

export async function removeTaskLinkAction(
  linkId: string
): Promise<{ ok: boolean }> {
  const user = await requireUser();
  const link = await prisma.taskLink.findUnique({ where: { id: linkId } });
  if (!link) return { ok: false };
  await assertCanEdit(link.taskId, user);
  await prisma.taskLink.delete({ where: { id: linkId } });
  revalidateTaskViews(link.taskId);
  return { ok: true };
}
